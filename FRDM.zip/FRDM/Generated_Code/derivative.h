/*
 * Note: This file is recreated by the project wizard whenever the MCU is
 *       changed and should not be edited by hand
 */

/* Include the derivative-specific header file */
#if 0 /* << EST */
  #include <MKL25Z4.h>
#else
  #include "Cpu.h"
#endif

#define __MK_xxx_H__
#define LITTLE_ENDIAN

