/*
 * Sem.h
 *
 *  Created on: 06.11.2014
 *      Author: tbsimmen
 */


#ifndef __SEM_H_
#define __SEM_H_

/*! \brief Initialization of the module */
void SEM_Init(void);

/*! \brief Deinitialization of the module */
void SEM_Deinit(void);

#endif /* __SEM_H_ */
