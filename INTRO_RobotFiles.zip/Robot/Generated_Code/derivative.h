/*
 * Note: This file is recreated by the project wizard whenever the MCU is
 *       changed and should not be edited by hand
 */

/* Include the derivative-specific header file */
#if 0 /* << EST */
  #include <MK21D5.h>
#else
  #include "Cpu.h"
#endif

#define __MK_xxx_H__
//#define USED_PIT0

